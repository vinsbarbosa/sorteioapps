gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDdragaoObjects1= [];
gdjs.Untitled_32sceneCode.GDdragaoObjects2= [];
gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects1= [];
gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDOvoObjects1= [];
gdjs.Untitled_32sceneCode.GDOvoObjects2= [];
gdjs.Untitled_32sceneCode.GDbackgObjects1= [];
gdjs.Untitled_32sceneCode.GDbackgObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDvinhetaObjects1= [];
gdjs.Untitled_32sceneCode.GDvinhetaObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite6Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite6Objects2= [];
gdjs.Untitled_32sceneCode.GDchaoObjects1= [];
gdjs.Untitled_32sceneCode.GDchaoObjects2= [];
gdjs.Untitled_32sceneCode.GDspawnerObjects1= [];
gdjs.Untitled_32sceneCode.GDspawnerObjects2= [];
gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1= [];
gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite7Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite7Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDOvoObjects1Objects = Hashtable.newFrom({"Ovo": gdjs.Untitled_32sceneCode.GDOvoObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32sceneCode.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.Untitled_32sceneCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Untitled_32sceneCode.GDNewText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ovo"), gdjs.Untitled_32sceneCode.GDOvoObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawner"), gdjs.Untitled_32sceneCode.GDspawnerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDOvoObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDOvoObjects1[i].getBehavior("Scale").setScale(gdjs.Untitled_32sceneCode.GDOvoObjects1[i].getBehavior("Scale").getScale() / (1.1));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite3Objects1[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspawnerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspawnerObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite4Objects1[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText2Objects1[i].getBehavior("Opacity").setOpacity(5);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "leonell-cassio-the-blackest-bouquet-118766.mp3", false, 5, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OrangeButtonWithStoneFrame"), gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1[k] = gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NumeroSorteado"), gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawner"), gdjs.Untitled_32sceneCode.GDspawnerObjects1);
gdjs.Untitled_32sceneCode.GDOvoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDOvoObjects1Objects, (( gdjs.Untitled_32sceneCode.GDspawnerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDspawnerObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDspawnerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDspawnerObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(0, 100)));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.Untitled_32sceneCode.GDNewSprite4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSprite4Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSprite4Objects1[k] = gdjs.Untitled_32sceneCode.GDNewSprite4Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://forms.gle/T3YLY5hYGtBHTak5A", runtimeScene);
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDdragaoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdragaoObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNumeroSorteadoObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOvoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOvoObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbackgObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbackgObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDvinhetaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDvinhetaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDchaoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDchaoObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDspawnerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDspawnerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeButtonWithStoneFrameObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
